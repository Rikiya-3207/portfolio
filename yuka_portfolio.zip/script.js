document.querySelector("form").addEventListener("submit", function (e) {
  e.preventDefault();
  alert("送信ありがとうございます！");
});
